package com.example.bloodpressurerecord.data.repository

import com.example.bloodpressurerecord.data.db.dao.MeasurementSessionDao
import com.example.bloodpressurerecord.data.db.entity.MeasurementReadingEntity
import com.example.bloodpressurerecord.data.db.entity.MeasurementSessionWithReadings
import com.example.bloodpressurerecord.data.db.entity.MeasurementSessionEntity
import com.example.bloodpressurerecord.domain.calculator.MeasurementInputRules
import com.example.bloodpressurerecord.domain.calculator.MeasurementDerivation
import com.example.bloodpressurerecord.domain.model.ReadingValue
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import java.util.UUID

class DefaultBloodPressureRepository(
    private val sessionDao: MeasurementSessionDao
) : BloodPressureRepository {

    override fun observeSessionCount(): Flow<Int> {
        return sessionDao.observeSessionCount()
    }

    override fun observeSessions(): Flow<List<SessionRecord>> {
        return sessionDao.observeSessionsWithReadings().map { list -> list.map { it.toRecord() } }
    }

    override fun observeSession(sessionId: String): Flow<SessionRecord?> {
        return sessionDao.observeSessionWithReadings(sessionId).map { it?.toRecord() }
    }

    override fun observeLatestSession(): Flow<SessionRecord?> {
        return sessionDao.observeLatestSessionWithReadings().map { it?.toRecord() }
    }

    override fun observeLatestSessionSummary(): Flow<LatestSessionSummary?> {
        return sessionDao.observeLatestSessionSummary().map { row ->
            row?.let {
                LatestSessionSummary(
                    id = it.id,
                    measuredAt = it.measuredAt,
                    avgSystolic = it.avgSystolic,
                    avgDiastolic = it.avgDiastolic,
                    category = it.category,
                    containsHighRiskReading = it.containsHighRiskReading
                )
            }
        }
    }

    override fun observeCalendarSessionSummaries(
        startInclusive: Long,
        endExclusive: Long
    ): Flow<List<CalendarSessionSummary>> {
        return sessionDao.observeCalendarSessionSummaries(startInclusive, endExclusive).map { rows ->
            rows.map {
                CalendarSessionSummary(
                    measuredAt = it.measuredAt,
                    containsHighRiskReading = it.containsHighRiskReading
                )
            }
        }
    }

    override fun observeSessionsInRange(
        startInclusive: Long,
        endExclusive: Long
    ): Flow<List<SessionRecord>> {
        return sessionDao.observeSessionsWithReadingsInRange(startInclusive, endExclusive)
            .map { rows -> rows.map { it.toRecord() } }
    }

    override fun observeSessionSummariesInRange(
        startInclusive: Long,
        endExclusive: Long
    ): Flow<List<SessionSummary>> {
        return sessionDao.observeSessionSummariesInRange(startInclusive, endExclusive)
            .map { rows -> rows.map(::toSummary) }
    }

    override fun observePeriodStatistics(
        startInclusive: Long,
        endExclusive: Long
    ): Flow<PeriodStatistics> {
        return sessionDao.observePeriodStatistics(startInclusive, endExclusive).map { row ->
            PeriodStatistics(
                recordCount = row.recordCount,
                averageSystolic = row.averageSystolic,
                averageDiastolic = row.averageDiastolic,
                averagePulse = row.averagePulse,
                highestSystolic = row.highestSystolic,
                highestDiastolic = row.highestDiastolic,
                lowestSystolic = row.lowestSystolic,
                lowestDiastolic = row.lowestDiastolic,
                highRiskCount = row.highRiskCount
            )
        }
    }

    override suspend fun saveSession(input: SaveSessionInput): Result<String> = runCatching {
        val sessionId = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val session = buildSessionEntity(
            sessionId = sessionId,
            input = input,
            createdAt = now,
            updatedAt = now
        )
        val readings = buildReadingEntities(sessionId, input.readings)
        sessionDao.insertSessionWithReadings(session, readings)
        sessionId
    }

    override suspend fun updateSession(sessionId: String, input: SaveSessionInput): Result<Unit> = runCatching {
        val existing = sessionDao.getSessionWithReadings(sessionId)
            ?: error("记录不存在，无法编辑")
        val now = System.currentTimeMillis()
        val session = buildSessionEntity(
            sessionId = sessionId,
            input = input,
            createdAt = existing.session.createdAt,
            updatedAt = now
        )
        val readings = buildReadingEntities(sessionId, input.readings)
        sessionDao.updateSessionWithReadings(session, readings)
    }

    override suspend fun deleteSession(sessionId: String): Result<Unit> = runCatching {
        sessionDao.deleteSessionById(sessionId)
    }

    override suspend fun restoreSession(session: SessionRecord): Result<Unit> = runCatching {
        val input = SaveSessionInput(
            measuredAt = session.measuredAt,
            scene = session.scene,
            note = session.note,
            symptoms = session.symptoms,
            readings = session.readings.sortedBy { it.orderIndex }.map {
                SessionReadingInput(it.systolic, it.diastolic, it.pulse)
            }
        )
        val entity = buildSessionEntity(
            sessionId = session.id,
            input = input,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        val readings = session.readings.sortedBy { it.orderIndex }.mapIndexed { index, reading ->
            MeasurementReadingEntity(
                id = reading.id,
                sessionId = session.id,
                orderIndex = index + 1,
                systolic = reading.systolic,
                diastolic = reading.diastolic,
                pulse = reading.pulse
            )
        }
        sessionDao.insertSessionWithReadings(entity, readings)
    }

    private fun buildSessionEntity(
        sessionId: String,
        input: SaveSessionInput,
        createdAt: Long,
        updatedAt: Long
    ): MeasurementSessionEntity {
        val readingValues = input.readings.map { ReadingValue(it.systolic, it.diastolic, it.pulse) }
        require(MeasurementInputRules.validateReadings(readingValues) == null) {
            "每次测量必须包含 ${MeasurementInputRules.MIN_READING_COUNT} 至 " +
                "${MeasurementInputRules.MAX_READING_COUNT} 组读数"
        }
        readingValues.forEachIndexed { index, reading ->
            require(MeasurementInputRules.validateReading(reading) == null) {
                "第 ${index + 1} 组读数不符合统一输入规则"
            }
        }
        val derived = MeasurementDerivation.derive(readingValues)
        val symptomsJson = if (input.symptoms.isEmpty()) null else JSONArray(input.symptoms).toString()
        return MeasurementSessionEntity(
            id = sessionId,
            measuredAt = input.measuredAt,
            scene = input.scene,
            note = input.note?.takeIf { it.isNotBlank() },
            symptomsJson = symptomsJson,
            avgSystolic = derived.average.avgSystolic,
            avgDiastolic = derived.average.avgDiastolic,
            avgPulse = derived.average.avgPulse,
            category = derived.category.name,
            containsHighRiskReading = derived.containsHighRiskReading,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    private fun buildReadingEntities(
        sessionId: String,
        inputs: List<SessionReadingInput>
    ): List<MeasurementReadingEntity> {
        return inputs.mapIndexed { index, reading ->
            MeasurementReadingEntity(
                id = UUID.randomUUID().toString(),
                sessionId = sessionId,
                orderIndex = index + 1,
                systolic = reading.systolic,
                diastolic = reading.diastolic,
                pulse = reading.pulse
            )
        }
    }

    private fun MeasurementSessionWithReadings.toRecord(): SessionRecord {
        val symptoms = parseSymptoms(session.symptomsJson)
        return SessionRecord(
            id = session.id,
            measuredAt = session.measuredAt,
            scene = session.scene,
            note = session.note,
            symptoms = symptoms,
            avgSystolic = session.avgSystolic,
            avgDiastolic = session.avgDiastolic,
            avgPulse = session.avgPulse,
            category = session.category,
            containsHighRiskReading = session.containsHighRiskReading,
            readings = readings.sortedBy { it.orderIndex }.map {
                SessionReading(
                    id = it.id,
                    orderIndex = it.orderIndex,
                    systolic = it.systolic,
                    diastolic = it.diastolic,
                    pulse = it.pulse
                )
            }
        )
    }

    private fun toSummary(
        row: com.example.bloodpressurerecord.data.db.dao.SessionSummaryRow
    ): SessionSummary {
        return SessionSummary(
            id = row.id,
            measuredAt = row.measuredAt,
            avgSystolic = row.avgSystolic,
            avgDiastolic = row.avgDiastolic,
            avgPulse = row.avgPulse,
            category = row.category,
            scene = row.scene,
            noteSummary = row.noteSummary,
            containsHighRiskReading = row.containsHighRiskReading
        )
    }

    private fun parseSymptoms(json: String?): List<String> {
        if (json.isNullOrBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(json)
            List(arr.length()) { index -> arr.getString(index) }
        }.getOrDefault(emptyList())
    }
}
